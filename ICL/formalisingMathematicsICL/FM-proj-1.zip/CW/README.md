# Formalizing Mathematics - Project 1

In this project I formalzied the existance part of the Lagrange Interpolation Theorem.
The file containing all my work is [here](./CW/Lagrange.lean).